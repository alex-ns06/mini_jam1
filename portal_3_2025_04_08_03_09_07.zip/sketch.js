
  x = 150
  y = 100
  xp = 100
  yp = 80
  azul = "rgb(151,151,255)"
  laranja = "rgb(255,179,40)"
  vermelho = "red"
  verde = "green"
  rosa = "rgb(241,11,255)"
  amarelo = "rgb(230,255,0)"
  ciano = "rgb(121,255,210)"
  roxo = "rgb(99,40,230)"
  branco = "rgb(255,255,255)"
  preto = "rgb(15,0,5)"
  portais =[];


function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(220);

  function criarPersonagem(){ 
    fill("rgb(191,149,71)")
    circle(x,y,23)
    
    fill("rgb(231,158,26)")
    rect(x-11,y+12,23,40)
    
  }
  function criarPortal(cor,xp,yp){
    fill(cor)
    ellipse(xp,yp,50,95)
    id = portais.length
    portais.push({
      id:id,
      x:xp,
      y:yp
    })
    
  }
  
  
  criarPersonagem()
  criarPortal(azul,xp,yp) //0
  criarPortal(laranja,xp+200,yp) //1
  criarPortal(vermelho,xp+200,yp + 115) //2
  criarPortal(verde,xp+200,yp+230) //3
  criarPortal(rosa,xp,yp+ 115) //4
  criarPortal(preto,xp,yp+230) //5
  criarPortal(ciano,xp,yp+345) //6
  criarPortal(roxo,xp,yp+465) //7
  criarPortal(amarelo,xp+200,yp+345) //8
  criarPortal(branco,xp+200,yp+465) //9
  
  function Teleportar(){
    portais.forEach((portal)=>{
      
    if(x < portal.x + 15 && x> portal.x -15){
      if(y < portal.y+30 && y> portal.y-75){
        
        if(portal.id == 0){
          console.log("azul")
          x = portais[1].x - 55
          y = portais[1].y
        }
        else if(portal.id == 1){
          console.log("laranja")
          x = portais[7].x + 25
          y = portais[7].y
        }
        else if(portal.id == 2){

          x = portais[2].x -25
          y = portais[2].y
        }
        else if(portal.id == 3){

          x = portais[0].x + 25
          y = portais[0].y
        }
        else if(portal.id == 4){

          x = portais[3].x - 25
          y = portais[3].y
        }
        else if(portal.id == 5){
 
          x = portais[3].x - 25
          y = portais[9].y
        }
        else if(portal.id == 6){
 
          x = portais[2].x - 25
          y = portais[2].y
        }
        else if(portal.id == 7){
 
          x = portais[8].x - 25
          y = portais[8].y
        }
        else if(portal.id == 9){
          x = portais[5].x + 25
          y = portais[5].y
        }

        }
       }
    });
  }
  s = deltaTime / 1000;
  let vel = 250
  x = constrain(x, 25, width - 25);
  y = constrain(y, 25, height - 25);
  
  if(keyIsDown(RIGHT_ARROW)){
    x += vel * s;    
    Teleportar()
  }else if(keyIsDown(LEFT_ARROW)){
    x -= vel * s;
    Teleportar()
  }
  if(keyIsDown(UP_ARROW)){
    y -= vel * s;   
    Teleportar()
  }else if(keyIsDown(DOWN_ARROW)){
    y += vel * s;  
    Teleportar()
    
  }
  

  
  
  
  
}

